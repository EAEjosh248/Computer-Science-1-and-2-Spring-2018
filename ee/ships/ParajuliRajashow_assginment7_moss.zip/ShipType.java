/**
 * enum class Types of ship
 * @author Rajashow
 * */
public enum ShipType {
	Cargo, Cruise, Warship, Carrier, Cruiser, Destroyer, Mine_Sweeper, Submarine
}
