
public class InvalidNotationFormatException extends RuntimeException {
	public InvalidNotationFormatException() {
		super("Inputed Notation format is incorrect");
	}
}
