
public class StackUnderflowException extends RuntimeException {
public StackUnderflowException() {super("when a push method is called on a full stack.");}
}
